package animations;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import biuoop.GUI;
import interfaces.Animation;

/**
 * The animations.AnimationRunner takes an interfaces.Animation object and runs it.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class AnimationRunner {
    //members.
    private GUI gui;
    private int framesPerSecond;

    /**
     * Constructor.
     *
     * @param gui             GUI of the Game.
     * @param framesPerSecond determines how much frames will run per one second.
     */
    public AnimationRunner(GUI gui, int framesPerSecond) {
        this.gui = gui;
        //gets 60
        this.framesPerSecond = framesPerSecond;
    }

    /**
     * runs the given interfaces.Animation's Frames until interfaces.Animation.shouldStop == true.
     *
     * @param animation - the given interfaces.Animation we run.
     */
    public void run(Animation animation) {
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        int millisecondsPerFrame = 1000 / this.framesPerSecond;
        //dt gets 1/60
        double dt = 1.0 / this.framesPerSecond;
        // 1 frame each iteration, shouldStop() is in charge of stopping condition.
        while (!animation.shouldStop()) {
            long startTime = System.currentTimeMillis(); // timing
            //a surface we can draw on
            DrawSurface d = gui.getDrawSurface();
            // doOneFrame(DrawSurface) is in charge of the logic.
            animation.doOneFrame(d, dt);
            gui.show(d);
            // timing - if it took us a shorter time than we expected - the function sleeps for the right time.
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }

    /**
     * return this GUI.
     *
     * @return this.gui
     */
    public GUI getGui() {
        return gui;
    }
}
