package animations;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Animation;

/**
 * extracts the "waiting-for-key-press" behavior away from the different Animations
 * into a animations.KeyPressStoppableAnimation decorator-class that will wrap an existing animation and
 * add a "waiting-for-key" behavior to it.
 */
public class KeyPressStoppableAnimation implements Animation {
    //members
    private KeyboardSensor sensor;
    private String key;
    private Animation animation;
    private boolean isAlreadyPressed;
    private boolean stop;

    /**
     * Constructor.
     *
     * @param sensor    KeyboardSensor
     * @param key       - describes the key that stops the interfaces.Animation
     * @param animation the interfaces.Animation we want to stop.
     */
    public KeyPressStoppableAnimation(KeyboardSensor sensor, String key, Animation animation) {
        this.sensor = sensor;
        this.key = key;
        this.animation = animation;
        //checks true when the stopping key is pressed once (makes sure it wont exit 2 screen)
        isAlreadyPressed = true;
        //when gets true it stop the interfaces.Animation
        this.stop = false;
    }

    /**
     * in charge of the logic of each animation.
     *
     * @param d  this drawsurface is given from the animations.AnimationRunner
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void doOneFrame(DrawSurface d, double dt) {
        //shows the interfaces.Animation one Frame
        this.animation.doOneFrame(d, dt);
        //if the stopping key is pressed once - stop the interfaces.Animation.
        if (this.sensor.isPressed(key) && !(isAlreadyPressed)) {
            this.stop = true;
        } else if (!(this.sensor.isPressed(key))) {
            isAlreadyPressed = false;
        }
    }

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}