package animations;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Animation;

/**
 * This interfaces.Animation pauses the game when we press the 'p' Key. We resume the game once we press SPACE Key.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class PauseScreen implements Animation {
    //members.
    private KeyboardSensor keyboard;
    private boolean stop;

    /**
     * Constructor.
     *
     * @param k KeyboardSensor
     */
    public PauseScreen(KeyboardSensor k) {
        this.keyboard = k;
        //determines when to stop this interfaces.Animation.
        this.stop = false;
    }

    /**
     * in charge of the logic of this animation.
     *
     * @param dt specifies the amount of seconds passed since the last call
     * @param d  this drawsurface is given from the animations.AnimationRunner
     */
    public void doOneFrame(DrawSurface d, double dt) {
        d.drawText(d.getWidth() / 5, d.getHeight() / 2, "paused -- press space to continue", 32);
    }

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        return false;
    }
}
