package animations;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Animation;
import interfaces.LevelInformation;
import levelsandgame.SpriteCollection;

import java.awt.Color;

/**
 * At the beginning of a level, and after a player loses a life, we would like to have a few seconds of wait
 * before the game starts. The feature we will add now is an on-screen countdown from 3 to 1,
 * which will show up at the beginning of each turn. Only after the countdown reaches zero,
 * things will start moving and we will start with the game play.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class CountdownAnimation implements Animation {
    //members
    private double numOfSeconds;
    private int countFrom;
    private SpriteCollection gameScreen;
    private boolean needToStop;
    private int counter;
    private LevelInformation levelInfo;

    /**
     * Constructor.
     *
     * @param numOfSeconds how much seconds this animation will last
     * @param countFrom    from which number we countdown
     * @param gameScreen   all the Sprites of the Game that called this interfaces.Animation
     * @param levelInfo    describes interfaces.LevelInformation of each level
     */
    public CountdownAnimation(double numOfSeconds, int countFrom, SpriteCollection gameScreen,
                              LevelInformation levelInfo) {
        this.numOfSeconds = numOfSeconds;
        this.countFrom = countFrom;
        this.gameScreen = gameScreen;
        //if gets true, we will stop this interfaces.Animation.
        this.needToStop = false;
        //counts how many times we called doOneFrame of this interfaces.Animation
        this.counter = 0;
        this.levelInfo = levelInfo;
    }

    /**
     * in charge of the logic of this animation.
     *
     * @param dt specifies the amount of seconds passed since the last call
     * @param d  this drawsurface is given from the animations.AnimationRunner
     */
    public void doOneFrame(DrawSurface d, double dt) {
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        //draw the Background while counting.
        levelInfo.getBackground().drawOn(d);
        gameScreen.drawAllOn(d);
        //the time lasts each count
        int millSecWait = (1000 * (int) numOfSeconds) / (1 + countFrom);
        //Sets White color because the first level's background color is Black.
        if (levelInfo.levelName().equals("Direct Hit")) {
            d.setColor(Color.WHITE);
        }
        //show each number/"GO" to
        if (counter == 0) {
            d.drawText(d.getWidth() / 2, d.getHeight() / 2, "3", 50);
        } else if (counter == 1) {
            d.drawText(d.getWidth() / 2, d.getHeight() / 2, "2", 50);
            sleeper.sleepFor(millSecWait);
        } else if (counter == 2) {
            d.drawText(d.getWidth() / 2, d.getHeight() / 2, "1", 50);
            sleeper.sleepFor(millSecWait);
        } else if (counter == 3) {
            d.drawText(d.getWidth() / 2, d.getHeight() / 2, "GO", 50);
            sleeper.sleepFor(millSecWait);
        } else {
            //if we printed all the above, stop this interfaces.Animation
            needToStop = true;
            sleeper.sleepFor(millSecWait);
        }
        counter++;
    }

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        return needToStop;
    }
}
