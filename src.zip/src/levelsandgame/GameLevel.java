package levelsandgame;
/*
 * Idan Twito
 * 311125249
 */

import animations.AnimationRunner;
import animations.CountdownAnimation;
import animations.KeyPressStoppableAnimation;
import animations.PauseScreen;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import blockandpaddle.Block;
import blockandpaddle.BlockRemover;
import blockandpaddle.Paddle;
import geometricshapes.Rectangle;
import geometricshapes.Point;
import geometricshapes.Ball;
import geometricshapes.BallRemover;
import geometricshapes.Velocity;
import indicators.ScoreIndicator;
import indicators.ScoreTrackingListener;
import indicators.LevelNameIndicator;
import indicators.LivesIndicator;
import indicators.Counter;
import interfaces.Animation;
import interfaces.Collidable;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;

/**
 * levelsandgame.GameLevel contains an ArrayList allSprites that contains all the Sprites of the game,
 * levelsandgame.GameEnvironment Object(contains all the collidables) and the GUI of the game.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class GameLevel implements Animation {
    //contains all the Sprites of this levelsandgame.GameLevel.
    private SpriteCollection allSprites;
    //contains all the Collidables of this levelsandgame.GameLevel.
    private GameEnvironment environment;
    //this object contains how much Blocks remained in the game.
    private Counter remainedBlock;
    //this object contains how much Balls remained in the game.
    private Counter remainedBalls;
    //this object contains the Score of the Player.
    private Counter score;
    ////this object contains how much lives left to the player.
    private Counter numberOfLives;
    //Runs the Animations
    private AnimationRunner runner;
    private boolean running;
    private KeyboardSensor keyboard;
    private LevelInformation levelInfo;

    /**
     * the constructor of levelsandgame.GameLevel object.
     *
     * @param runner        animations.AnimationRunner Object
     * @param levelInfo     describes a level in the game
     * @param score         indicates the score of the game
     * @param numberOfLives indicates the remaining lives of the player
     */
    public GameLevel(AnimationRunner runner, LevelInformation levelInfo, Counter score, Counter numberOfLives) {
        this.allSprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.remainedBlock = new Counter(0);
        this.remainedBalls = new Counter(0);
        this.score = score;
        this.numberOfLives = numberOfLives;
        this.running = true;
        this.runner = runner;
        this.keyboard = this.runner.getGui().getKeyboardSensor();
        this.levelInfo = levelInfo;
    }

    /**
     * the function gets a new collidable and adds it the the levelsandgame.GameEnvironment's collidables list.
     *
     * @param c - new collidable in the game environment
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * adds the given sprite to the list.
     *
     * @param s - the given sprite we want to add to the sprites list
     */
    public void addSprite(Sprite s) {
        this.allSprites.addSprite(s);
    }

    // Initialize a new game: create the Blocks and geometricshapes.Ball (and blockandpaddle.Paddle)
    // and add them to the game.

    /**
     * this function initializes a new game: it creates the Blocks and geometricshapes.
     * Ball (and blockandpaddle.Paddle) and add them to the game.
     */
    public void initialize() {
        //adding a score indicator to the game
        ScoreIndicator scoreIndicator = new ScoreIndicator(score);
        scoreIndicator.addToGame(this);
        //adding a player's lives indicator to the game
        LivesIndicator livesIndicator = new LivesIndicator(numberOfLives);
        livesIndicator.addToGame(this);
        //adding a Level Name indicator to the game
        LevelNameIndicator levelNameIndicator = new LevelNameIndicator(levelInfo);
        levelNameIndicator.addToGame(this);
        //makes this levelsandgame.GameLevel's score Listener.
        ScoreTrackingListener scoreCounter = new ScoreTrackingListener(this.score);
        //in charge of removing Balls from the game

        //in charge of removing Blocks from the game
        BlockRemover blockRemover = new BlockRemover(this, this.remainedBlock);
        //will get the upperLeft geometricshapes.Point of each block that we'll create
        Point upperLeftBlockP;
        //gets the rectangle of each blockandpaddle.Block we'll create
        Rectangle gameRectangle;
        //gets the Color Object of each blockandpaddle.Block we'll create
        Color rectangleColor = Color.GRAY;


        //creating all the Blocks of each Level
        for (Block gameBlock : levelInfo.blocks()) {
            //adding all the Blocks to this Game.
            gameBlock.addToGame(this);
            //increases the blocks number in the game by one
            remainedBlock.increase(1);
            //adding each correlate gameBlock's blockRemover to the hitListeners List
            gameBlock.addHitListener(blockRemover);
            //whenever there's a hit with a gameBlock, the scoreCounter will be notified
            gameBlock.addHitListener(scoreCounter);

            createBoundaries();
        }


    }

    /**
     * creates the same Boundaries Blocks in each Level.
     */
    public void createBoundaries() {
        //Here we create all the 4 edge blocks of the game
        Point p15 = new Point(0, 25);
        Rectangle topRect = new Rectangle(p15, 800, 20);
        Block topBlock = new Block(topRect, Color.GRAY, 0);
        Rectangle leftRect = new Rectangle(p15, 25, 600);
        Block leftBlock = new Block(leftRect, Color.GRAY, 0);
        Point p10 = new Point(0, 650);
        Rectangle bottomRect = new Rectangle(p10, 800, 20);
        Block bottomBlock = new Block(bottomRect, Color.GRAY, 0);
        BallRemover ballRemover = new BallRemover(this, remainedBalls);
        //register the geometricshapes.BallRemover class as a listener of the death-region.
        bottomBlock.addHitListener(ballRemover);
        Point p11 = new Point(776, 25);
        Rectangle rightRect = new Rectangle(p11, 25, 600);
        Block rightBlock = new Block(rightRect, Color.GRAY, 0);

        //adding all these 4 blocks to the game
        topBlock.addToGame(this);
        bottomBlock.addToGame(this);
        leftBlock.addToGame(this);
        rightBlock.addToGame(this);

    }

    /**
     * this function starts the game.
     */
    public void run() {
        while (this.numberOfLives.getValue() > 0) {
            playOneTurn();
        }
    }

    /**
     * this method creates the Balls on top of the blockandpaddle.Paddle.
     */
    public void createBallsOnTopOfPaddle() {
        for (int i = 0; i < levelInfo.numberOfBalls(); i++) {
            Point firstCenter = new Point(400, 555);
            Velocity velocity = levelInfo.initialBallVelocities().get(i);
            Ball ballOne = new Ball(firstCenter, 5, Color.WHITE, 20, 600, 780, 20);
            ballOne.setGameEnvironment(environment);
            ballOne.setVelocity(velocity);
            ballOne.addToGame(this);
            this.remainedBalls.increase(1);
        }
    }


    /**
     * this function starts the animation loop of every turn. It creates the game's:
     * blockandpaddle.Paddle and Balls
     * Tells when the player lost this Turn, and when the game is over
     * counts the lives and the score of the player using assisting methods
     */
    public void playOneTurn() {
        //creating the Balls
        createBallsOnTopOfPaddle();
        //creating the blockandpaddle.Paddle of the game in the center of the screen
        Point rectangleUpperLeft = new Point((800 - levelInfo.paddleWidth()) / 2, 560);
        Rectangle paddleRect = new Rectangle(rectangleUpperLeft, levelInfo.paddleWidth(), 20);
        Paddle gamePaddle = new Paddle(keyboard, Color.orange, paddleRect, levelInfo.paddleSpeed(), 20, 780);
        gamePaddle.addToGame(this);
        //countdown before turn starts.
        this.runner.run(new CountdownAnimation(2, 3, allSprites, levelInfo));
        this.running = true;
        // use our runner to run the current animation -- which is one turn of the game.
        this.runner.run(this);
        //removes the blockandpaddle.Paddle of this Game once the player lost a round or the whole Game.
        gamePaddle.removeFromGame(this);

    }

    /**
     * removes the given collidable from the list that contains all the collidables in the game.
     *
     * @param c the collidable we want to remove from the list
     */
    public void removeCollidable(Collidable c) {
        this.environment.getCollidableObjectsList().remove(c);
    }

    /**
     * removes the given sprite from the list that contains all the sprites in the game.
     *
     * @param s the sprite we want to remove from the list
     */
    public void removeSprite(Sprite s) {
        this.allSprites.getSpriteObjectsList().remove(s);
    }

    /**
     * returns the current score of the player.
     *
     * @return indicators.Counter this.score
     */
    public Counter getScore() {
        return this.score;
    }

    /**
     * @param d  this drawsurface is given from the animations.AnimationRunner
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void doOneFrame(DrawSurface d, double dt) {

        this.levelInfo.getBackground().drawOn(d);
        //creating animations.PauseScreen
        PauseScreen pauseScreen = new PauseScreen(keyboard);
        KeyPressStoppableAnimation pauseScreenK = new KeyPressStoppableAnimation(keyboard, "space", pauseScreen);
        //draw all sprites
        this.allSprites.drawAllOn(d);
        //notify all sprites the time has passed
        this.allSprites.notifyAllTimePassed(dt);
        //pausing the game until we press "p" button.
        if (this.keyboard.isPressed("p")) {
            this.runner.run(pauseScreenK);
        }
    }

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean needToStop.
     */

    public boolean shouldStop() {
        //if no more Blocks remained - finish the game.
        if (this.remainedBlock.getValue() == 0) {
            //this.runner.getGui().close();
            return this.running;
        }
        //if all the Balls fell fall from the screen - number of Lives decreases by one
        if (this.remainedBalls.getValue() == 0) {
            this.numberOfLives.decrease(1);
            //remove the paddle from the game
            //gamePaddle.removeFromGame(this);
            if (this.numberOfLives.getValue() > 0) {
                return this.running;
            } else {
                //if the number of lives is 0 - Game Over.
                //this.runner.getGui().close();
                return this.running;
            }
        }
        return !this.running;
    }

    /**
     * returns the number of the remaining lives(useful to save this number from each level to the next one).
     *
     * @return int this.numberOfLives.getValue()
     */
    public int getLives() {
        return this.numberOfLives.getValue();
    }

    /**
     * returns the score of the player(useful to save this number from each level to the next one).
     *
     * @return int this.remainedBlock.getValue()
     */
    public int getRemainedBlocks() {
        return this.remainedBlock.getValue();
    }

    /**
     * returns the remained balls in the game.
     *
     * @return indicators.Counter Object.
     */
    public Counter getRemainedBalls() {
        return this.remainedBalls;
    }
}
