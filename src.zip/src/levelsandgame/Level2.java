package levelsandgame;
/*
 * Idan Twito
 * 311125249
 */

import backgrounds.Background2;
import blockandpaddle.Block;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import geometricshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Describes the second level by implementing interfaces.LevelInformation.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class Level2 implements LevelInformation {

    /**
     * number of balls in this Level.
     *
     * @return 10
     */
    public int numberOfBalls() {
        return 10;
    }

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return List<geometricshapes.Velocity> ballsVelocities
     */
    public List<Velocity> initialBallVelocities() {
        Velocity velocity;
        List<Velocity> ballsVelocities = new ArrayList<Velocity>();
        for (int i = 0; i < 10; i++) {
            velocity = Velocity.fromAngleAndSpeed(120 + (i * (120 / 9)), 420);
            ballsVelocities.add(velocity);
        }
        return ballsVelocities;
    }

    /**
     * the blockandpaddle.Paddle's geometricshapes.Velocity.
     *
     * @return 5
     */
    public int paddleSpeed() {
        return 300;
    }

    /**
     * The blockandpaddle.Paddle's Width.
     *
     * @return 500
     */
    public int paddleWidth() {
        return 500;
    }

    /**
     * the level name will be displayed at the top of the screen.
     *
     * @return "Wide Easy"
     */
    public String levelName() {
        return ("Wide Easy");
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return backgrounds.Background2 background
     */
    public Sprite getBackground() {
        Background2 background = new Background2();
        return background;
    }

    /**
     * The Blocks that make up this level, each block contains.
     * its size, color and location.
     *
     * @return List<blockandpaddle.Block> blocksList
     */
    public List<Block> blocks() {
        List<Block> blocksList = new ArrayList<Block>();
        Point point;
        Rectangle rectangle;
        Block block;
        Color color;
        for (int i = 0; i < 15; i++) {
            if (i == 0 || i == 1) {
                color = Color.RED;
            } else if (i == 2 || i == 3) {
                color = Color.ORANGE;
            } else if (i == 4 || i == 5) {
                color = Color.YELLOW;
            } else if (i == 6 || i == 7 || i == 8) {
                color = Color.GREEN;
            } else if (i == 9 || i == 10) {
                color = Color.BLUE;
            } else if (i == 11 || i == 12) {
                color = Color.PINK;
            } else {
                color = Color.cyan;
            }
            point = new Point(20 + (i * 760 / 15), 220);
            rectangle = new Rectangle(point, 760 / 15, 20);
            block = new Block(rectangle, color);
            blocksList.add(block);
        }
        return blocksList;
    }

    /**
     * Number of levelsandgame that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size().
     *
     * @return 15
     */
    public int numberOfBlocksToRemove() {
        return 15;
    }
}

