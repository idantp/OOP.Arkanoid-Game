package levelsandgame;
/*
 * Idan Twito
 * 311125249
 */

import backgrounds.Background4;

import blockandpaddle.Block;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import geometricshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Describes the fourth level by implementing interfaces.LevelInformation.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class Level4 implements LevelInformation {

    /**
     * number of balls in this Level.
     *
     * @return 1
     */
    public int numberOfBalls() {
        return 1;
    }

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return List<geometricshapes.Velocity> ballsVelocities
     */
    public List<Velocity> initialBallVelocities() {
        List<Velocity> ballsVelocities = new ArrayList<Velocity>();
        Velocity velocity = new Velocity(4 * 60, 5 * 60);
        ballsVelocities.add(velocity);
        return ballsVelocities;
    }

    /**
     * the blockandpaddle.Paddle's geometricshapes.Velocity.
     *
     * @return 7
     */
    public int paddleSpeed() {
        return 7 * 60;
    }

    /**
     * The blockandpaddle.Paddle's Width.
     *
     * @return 100
     */
    public int paddleWidth() {
        return 100;
    }

    /**
     * the level name will be displayed at the top of the screen.
     *
     * @return "Final Four"
     */
    public String levelName() {
        return ("Final Four");
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return backgrounds.Background4 background
     */
    public Sprite getBackground() {
        Background4 background = new Background4();
        return background;
    }

    /**
     * The Blocks that make up this level, each block contains.
     * its size, color and location.
     *
     * @return List<blockandpaddle.Block> blocksList
     */
    public List<Block> blocks() {
        List<Block> blocksList = new ArrayList<Block>();
        Color rectangleColor;
        Point upperLeftBlockP;
        Rectangle gameRectangle;
        int hitPoints;
        Block gameBlock;
        //creating all the Blocks of the game
        for (int i = 0; i < 7; i++) {
            //the height of each blockandpaddle.Block is 20
            double y = 20 * i;
            for (int j = 0; j < 15; j++) {
                //each line of Blocks gets a different Color.
                if (i == 0) {
                    rectangleColor = Color.GRAY;
                } else if (i == 1) {
                    rectangleColor = Color.RED;
                } else if (i == 2) {
                    rectangleColor = Color.YELLOW;
                } else if (i == 3) {
                    rectangleColor = Color.GREEN;
                } else if (i == 4) {
                    rectangleColor = Color.WHITE;
                } else if (i == 5) {
                    rectangleColor = Color.PINK;
                } else {
                    rectangleColor = Color.cyan;
                }
                //the width of each blockandpaddle.Block is 20
                double x = (double) ((760.0 / 15.0) * j);
                //gets the upperLeft geometricshapes.Point of each block
                upperLeftBlockP = new Point((20 + x), (100 + y));
                //gets the rectangle of each blockandpaddle.Block
                gameRectangle = new Rectangle(upperLeftBlockP, (760 / 15), 20);
                //the first line's Blocks gets hit-Points of 2, the rest get 1
                if (i == 0) {
                    hitPoints = 2;
                } else {
                    hitPoints = 1;
                }
                gameBlock = new Block(gameRectangle, rectangleColor, hitPoints);
                blocksList.add(gameBlock);
            }
        }
        return blocksList;
    }


    /**
     * Number of levelsandgame that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size().
     *
     * @return 105
     */
    public int numberOfBlocksToRemove() {
        return 105;
    }
}

