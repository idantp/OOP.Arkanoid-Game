package geometricshapes;
/*
 * Idan Twito
 * 311125249
 */

/**
 * geometricshapes.Velocity specifies the change in position on the `x` and the `y` axes.
 *
 * @ 26.03.18
 * @ author: Idan Twito
 */
public class Velocity {
    private double dx;
    private double dy;

    /**
     * constructor.
     *
     * @param dx - sets the movement at the x axle.
     * @param dy - sets the movement at the y axle.
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * defining the velocity in terms of speed and angle instead of dx, dy.
     *
     * @param angle - the function gets double angle and converts it into dx,dy terms.
     * @param speed - the function gets double speed and converts it into dx,dy terms.
     * @return geometricshapes.Velocity variable defined with dx, dy.
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        angle = Math.toRadians(angle);
        double dx = Math.sin(angle) * (speed);
        double dy = Math.cos(angle) * (speed);
        return new Velocity(dx, -dy);
    }

    /**
     * The function takes a point with position (x,y) and returns a new point with position (x+dx, y+dy).
     *
     * @param p - the given Points we want to change its position.
     * @return newP (geometricshapes.Point) - the new point with the new position.
     */
    public Point applyToPoint(Point p) {
        Point newP;
        double x = p.getX();
        double y = p.getY();
        //if the point is not set, return null.
        if (p == null) {
            return null;
        } else {
            //summing ang getting the new coordinates.
            x += this.dx;
            y += this.dy;
            newP = new Point(x, y);
            return newP;
        }
    }

    /**
     * the function returns the progress in the x axle.
     *
     * @return double this.dx
     */
    public double getDx() {
        return this.dx;
    }

    /**
     * the function returns the progress in the y axle.
     *
     * @return double this.dy
     */
    public double getDy() {
        return this.dy;
    }
}
