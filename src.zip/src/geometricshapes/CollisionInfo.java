package geometricshapes;
/*
 * Idan Twito
 * 311125249
 */

import interfaces.Collidable;

/**
 * this Object contains a geometricshapes.Point and a interfaces.Collidable. given the fact there was a collision
 * between a other object
 * and a collidable, the geometricshapes.Point of this object contains the collision geometricshapes.Point,
 * and the interfaces.Collidable contains the collidable that collided with the ball.
 *
 * @ 20.04.18
 * @ last update 21.05.18
 * @ author: Idan Twito
 */
public class CollisionInfo {
    private Point collisionPoint;
    private Collidable collisionObject;

    /**
     * the constructor.
     *
     * @param collisionPoint  - the collision geometricshapes.Point
     * @param collisionObject - the colliding interfaces.Collidable with the other object
     */
    public CollisionInfo(Point collisionPoint, Collidable collisionObject) {
        this.collisionPoint = collisionPoint;
        this.collisionObject = collisionObject;
    }

    /**
     * the function returns the point at which the collision occurs.
     *
     * @return - geometricshapes.Point this.collisionPoint
     */
    public Point collisionPoint() {
        return this.collisionPoint;
    }

    /**
     * the function returns the collidable object involved in the collision.
     *
     * @return interfaces.Collidable this.collisionObject
     */
    public Collidable collisionObject() {
        return this.collisionObject;
    }
}
