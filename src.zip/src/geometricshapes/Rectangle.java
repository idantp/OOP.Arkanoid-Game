package geometricshapes;
/*
 * Idan Twito
 * 311125249
 */

import java.util.ArrayList;
import java.util.List;

/**
 * geometricshapes.Rectangle describes a geometricshapes.Rectangle object. A geometricshapes.
 * Rectangle contains upperLeft geometricshapes.Point, width and height.
 *
 * @ 20.04.18
 * @ author: Idan Twito
 */
public class Rectangle {

    private Point upperLeft;
    private double width;
    private double height;

    // Create a new rectangle with location and width/height.

    /**
     * Create a new rectangle with location and width/height. This function is the constructor
     *
     * @param upperLeft the upper left point of the rectangle
     * @param width     the width of the rectangle
     * @param height    the height of the rectangle
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
    }

    /**
     * the function gets a line and checks whether it intersects with the rectangle's sides. The function
     * returns a list that contains all the intersection points
     *
     * @param line the line we want to check whether it intersects the rectangle or not.
     * @return the list the contain all the intersection points, might be empty.
     */
    public List<Point> intersectionPoints(Line line) {
        Line upperLine = new Line(this.getUpperLeft(), this.getUpperRight());
        Line lowerLine = new Line(this.getLowerLeft(), this.getLowerRight());
        Line rightLine = new Line(this.getLowerRight(), this.getUpperRight());
        Line leftLine = new Line(this.getLowerLeft(), this.getUpperLeft());
        //contains all the intersection Points of the given line with side of this geometricshapes.Rectangle
        List<Point> intersectionPList = new ArrayList<Point>();
        //checking the intersection of the give line with each side of this geometricshapes.Rectangle
        if (upperLine.isIntersecting(line)) {
            intersectionPList.add(upperLine.intersectionWith(line));
        }
        if (lowerLine.isIntersecting(line)) {
            intersectionPList.add(lowerLine.intersectionWith(line));
        }
        if (rightLine.isIntersecting(line)) {
            intersectionPList.add(rightLine.intersectionWith(line));
        }
        if (leftLine.isIntersecting(line)) {
            intersectionPList.add(leftLine.intersectionWith(line));
        }
        return intersectionPList;
    }

    /**
     * The function returns the upper right point coordinate of the rectangle.
     *
     * @return geometricshapes.Point upperRightP.
     */
    public Point getUpperRight() {
        Point upperRightP = new Point(upperLeft.getX() + this.getWidth(), upperLeft.getY());
        return upperRightP;
    }

    /**
     * The function returns the lower left point coordinate of the rectangle.
     *
     * @return geometricshapes.Point lowerLeftP
     */
    public Point getLowerLeft() {
        Point lowerLeftP = new Point(upperLeft.getX(), upperLeft.getY() + this.getHeight());
        return lowerLeftP;
    }

    /**
     * The function returns the lower right point coordinate of the rectangle.
     *
     * @return geometricshapes.Point lowerRightP
     */
    public Point getLowerRight() {
        Point lowerRightP = new Point(upperLeft.getX() + this.getWidth(), upperLeft.getY() + this.getHeight());
        return lowerRightP;
    }

    /**
     * The function returns the upper left point coordinate of the rectangle.
     *
     * @return this.upperLeft
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }

    /**
     * The function returns the upper line of the rectangle.
     *
     * @return geometricshapes.Line l1
     */
    public Line getUpperLine() {
        Line l1 = new Line(this.getUpperLeft(), this.getUpperRight());
        return l1;
    }

    /**
     * The function returns the right line of the rectangle.
     *
     * @return geometricshapes.Line l1
     */
    public Line getRightLine() {
        Line l1 = new Line(this.getLowerRight(), this.getUpperRight());
        return l1;
    }

    /**
     * The function returns the lower line of the rectangle.
     *
     * @return geometricshapes.Line l1
     */
    public Line getLowerLine() {
        Line l1 = new Line(this.getLowerLeft(), this.getLowerRight());
        return l1;
    }

    /**
     * The function returns the left line of the rectangle.
     *
     * @return geometricshapes.Line l1
     */
    public Line getLeftLine() {
        Line l1 = new Line(this.getLowerLeft(), this.getUpperLeft());
        return l1;
    }

    /**
     * The function returns the width of the rectangle.
     *
     * @return this.width
     */
    public double getWidth() {
        return this.width;
    }

    /**
     * The function returns the height of the rectangle.
     *
     * @return this.height
     */
    public double getHeight() {
        return this.height;
    }

    /**
     * changing the location of this geometricshapes.Rectangle.
     *
     * @param newUpperLeft - the new upperLeft geometricshapes.Point of this geometricshapes.Rectangle.
     */
    public void setUpperLeft(Point newUpperLeft) {
        this.upperLeft = newUpperLeft;
    }
}
