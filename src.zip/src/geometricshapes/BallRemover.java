package geometricshapes;
/*
 * Idan Twito
 * 311125249
 */

import blockandpaddle.Block;
import indicators.Counter;
import interfaces.HitListener;
import levelsandgame.GameLevel;

/**
 * a geometricshapes.BallRemover is in charge of removing balls from the game, as well as keeping count
 * of the number of balls that remain.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class BallRemover implements HitListener {
    //members
    private GameLevel game;
    private Counter remainingBalls;

    /**
     * the constructor.
     *
     * @param game           the game we want to be able to remove the Balls from
     * @param remainingBalls indicators.Counter object which contains number of the remaining Balls in this Game.
     */
    public BallRemover(GameLevel game, Counter remainingBalls) {
        this.game = game;
        this.remainingBalls = remainingBalls;
    }


    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the geometricshapes.Ball that's doing the hitting.
     *
     * @param beingHit the blockandpaddle.Block that was involved in the hit
     * @param hitter   the geometricshapes.Ball that was involved in the hit
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        //remove this hitter (geometricshapes.Ball) from the Game.
        hitter.removeFromGame(this.game);
        //decreasing the amount of the Balls in the Game by one.
        this.remainingBalls.decrease(1);
    }
}
