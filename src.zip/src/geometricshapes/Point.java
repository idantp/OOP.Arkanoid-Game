package geometricshapes;
/*
 * Idan Twito
 * 311125249
 */

/**
 * geometricshapes.Point describes geometricshapes.Point object. A point contains x,y coordinates
 *
 * @ 26.03.18
 * @ author: Idan Twito
 */
public class Point {
    //the members of geometricshapes.Point
    private double x;
    private double y;

    /**
     * the constructor of geometricshapes.Point.
     *
     * @param x represents the x coordinate
     * @param y represents the y coordinate
     */
    public Point(double x, double y) {
        //the constructor of geometricshapes.Point
        this.x = x;
        this.y = y;
    }

    /**
     * The function calculates the distance between two points.
     *
     * @param other - geometricshapes.Point object
     * @return pointsDistance - the distance between the two points
     */
    public double distance(Point other) {
        double pointsDistance;
        double pointsSum;
        //gets the (distance)^2 of the two points
        pointsSum = (Math.pow(this.x - other.getX(), 2)) + (Math.pow(this.y - other.getY(), 2));
        //gets the exact distance of the two points
        pointsDistance = Math.sqrt(pointsSum);
        return pointsDistance;
    }

    /**
     * checks whether two points are equal or not. if the do - return true, else - false.
     *
     * @param other - the second points.
     * @return true if the two points are equal, false if one of the points isn't defined, or the points not equal.
     */
    public boolean equals(Point other) {
        //if one of the points is not defined return false
        if (this == null || other == null) {
            return false;
        }
        //if the points are equal return true.
        if (this.getX() == other.getX() && this.getY() == other.getY()) {
            return true;
        }
        return false;
    }

    /**
     * the function returns the x coordinate of the function.
     *
     * @return this.x
     */
    public double getX() {
        return this.x;
    }

    /**
     * the function returns the y coordinate of the function.
     *
     * @return this.y
     */
    public double getY() {
        return this.y;
    }
}