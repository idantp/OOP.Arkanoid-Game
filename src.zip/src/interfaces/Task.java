package interfaces;
/*
 * Idan Twito
 * 311125249
 */

/**
 * A task is something that needs to happen, or something that we can run() and return a value.
 *
 * @param <T>
 */
public interface Task<T> {
    /**
     * runs the desired animation when we press the interfaces.Animation's key.
     *
     * @return Void.
     */
    T run();
}
