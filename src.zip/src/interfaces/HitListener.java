package interfaces;
/*
 * Idan Twito
 * 311125249
 */

import blockandpaddle.Block;
import geometricshapes.Ball;

/**
 * Objects that want to be notified of hit events, should implement the interfaces.HitListener interface.
 */
public interface HitListener {
    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the geometricshapes.Ball that's doing the hitting.
     *
     * @param beingHit the blockandpaddle.Block that was involved in the hit
     * @param hitter   the geometricshapes.Ball that was involved in the hit
     */
    void hitEvent(Block beingHit, Ball hitter);
}
