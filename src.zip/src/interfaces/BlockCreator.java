package interfaces;
/*
 * Idan Twito
 * 311125249
 */

import blockandpaddle.Block;

/**
 * an interface of a factory-object that is used for creating blocks.
 * When reading the file, the code in readingfromfiles.BlocksDefinitionReader will create the
 * appropriate interfaces.BlockCreator implementations according to the definitions in the bdef lines,
 * and populate the blockandpaddle.BlocksFromSymbolsFactory with the BlockCreators and their associated symbols.
 */
public interface BlockCreator {
    /**
     * Create a block at the specified location.
     *
     * @param xpos x coordinate of the upperleft geometricshapes.Point
     * @param ypos y coordinate of the upperleft geometricshapes.Point
     * @return  void
     */
    Block create(int xpos, int ypos);

}
