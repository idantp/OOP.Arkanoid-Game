package interfaces;
/*
 * Idan Twito
 * 311125249
 */

/**
 * The interfaces.HitNotifier interface indicates objects that implement it and
 * send notifications when they are being hit.
 */
public interface HitNotifier {
    /**
     * Add hl as a listener to hit events.
     *
     * @param hl an Object that is notified of hit events
     */
    void addHitListener(HitListener hl);

    /**
     * Remove hl from the list of listeners to hit events.
     *
     * @param hl an Object that is notified of hit events
     */
    void removeHitListener(HitListener hl);
}
