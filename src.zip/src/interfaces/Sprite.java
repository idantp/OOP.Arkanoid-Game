package interfaces;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;

/**
 * A interfaces.Sprite is a game object that can be drawn to the screen (and which is not just a background image.
 * Sprites can be drawn on the screen, and can be notified that time has passed,
 * so they know to change their position, shape, appearance, etc.
 * @ 20.04.18
 * @ author: Idan Twito

 */
public interface Sprite {

    /**
     * the function draws the sprite on the screen (using DrawSurface d).
     *
     * @param d - the DrawSurface of the GUI we'll create later.
     */
    void drawOn(DrawSurface d);

    /**
     * notify the sprite that time has passed.
     * @param dt specifies the amount of seconds passed since the last call
     */
    void timePassed(double dt);

}
