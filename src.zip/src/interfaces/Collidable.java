package interfaces;
/*
 * Idan Twito
 * 311125249
 */

import geometricshapes.Ball;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import geometricshapes.Velocity;

/**
 * This interface describes Objects we can collide with(in this assignment:
 * blockandpaddle.Block and blockandpaddle.Paddle).
 */
public interface Collidable {
    /**
     * the function returns the object of the colliding object.
     *
     * @return - the object of the colliding object.
     */
    Rectangle getCollisionRectangle();

    /**
     * given there was a collision of an object with this Object, the function returns the new velocity
     * of the colliding object after the hit with this Object.
     *
     * @param collisionPoint  geometricshapes.Point that describes the collision point.
     * @param currentVelocity geometricshapes.Velocity - the current velocity of the colliding object.
     * @param hitter          the geometricshapes.Ball that is involved in the this hit.
     * @return the velocity after the collision
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}
