package interfaces;
/*
 * Idan Twito
 * 311125249
 */

/**
 * interfaces.Menu Interface. each menu selection contains a key (when this key is pressed in the menu
 * the specific interfaces.Animation runs), message (describes the next interfaces.Animation),
 * returnVal (creating and running the specific interfaces.Animation).
 *
 * @param <T> a Generic variable/object.
 */
public interface Menu<T> extends Animation {
    /**
     * adds a new selection(interfaces.Animation) to the main menu.
     *
     * @param key       - String - when this key is pressed in the menu the specific interfaces.Animation runs
     * @param message   - String - describes the next interfaces.Animation
     * @param returnVal T - creating and running the specific interfaces.Animation
     */
    void addSelection(String key, String message, T returnVal);

    /**
     * do something according to status:
     * play a game, show high score, or quit.
     *
     * @return return the status (options described above).
     */
    T getStatus();

    /**
     * adds a new sub interfaces.Menu to the main menu.
     *
     * @param key     - when this key is pressed in the menu the specific sub menu runs
     * @param message - String - describes the next sub menu
     * @param subMenu - creating and displaying the specific sub menu
     */
    void addSubMenu(String key, String message, Menu<T> subMenu);
}