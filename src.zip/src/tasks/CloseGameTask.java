package tasks;
/*
 * Idan Twito
 * 311125249
 */

import interfaces.Task;

/**
 * * Once "q" is pressed in the menu, this task closes the Game.
 */
public class CloseGameTask implements Task<Void> {
    /**
     * exits from the Game.
     *
     * @return null.
     */
    public Void run() {
        System.exit(1);
        return null;
    }
}
