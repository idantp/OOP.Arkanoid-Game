package backgrounds;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;

/**
 * This Class describes the Background of levelsandgame.Level2 Class by implementing interfaces.Sprite.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class Background2 implements Sprite {

    /**
     * the function draws the sprite on the screen (using DrawSurface d).
     *
     * @param d - the DrawSurface of the GUI we'll create later.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(Color.WHITE);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(new Color(241, 237, 198));
        for (int i = 0; i < 150; i++) {
            d.drawLine(150, 120, 5 * i, 220);
        }
        d.fillCircle(150, 120, 60);
        d.setColor(new Color(241, 238, 137));
        d.fillCircle(150, 120, 50);
        d.setColor(new Color(255, 251, 1));
        d.fillCircle(150, 120, 40);
    }

    /**
     * notify the sprite that time has passed.
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {

    }
}
