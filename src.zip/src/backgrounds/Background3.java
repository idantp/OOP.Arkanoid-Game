package backgrounds;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;

/**
 * This Class describes the Background of levelsandgame.Level3 Class by implementing interfaces.Sprite.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class Background3 implements Sprite {

    /**
     * the function draws the sprite on the screen (using DrawSurface d).
     *
     * @param d - the DrawSurface of the GUI we'll create later.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(new Color(102, 208, 136));
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(new Color(26, 32, 22));
        d.fillRectangle(100, 400, 120, 200);
        d.setColor(new Color(87, 84, 81));
        d.fillRectangle(135, 330, 50, 70);
        d.setColor(new Color(110, 106, 103));
        d.fillRectangle(152, 180, 15, 150);
        d.setColor(new Color(255, 255, 255));
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                d.fillRectangle((112 + (20 * j)), ((50 * i) + 410), 12, 30);
            }
        }
        d.setColor(new Color(241, 238, 137));
        d.fillCircle(160, 165, 15);
        d.setColor(new Color(241, 192, 65));
        d.fillCircle(160, 165, 10);
        d.setColor(new Color(241, 144, 61));
        d.fillCircle(160, 165, 5);


    }

    /**
     * notify the sprite that time has passed.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {

    }
}
