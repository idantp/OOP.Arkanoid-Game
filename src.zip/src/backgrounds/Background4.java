package backgrounds;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;

/**
 * This Class describes the Background of levelsandgame.Level4 Class by implementing interfaces.Sprite.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class Background4 implements Sprite {

    /**
     * the function draws the sprite on the screen (using DrawSurface d).
     *
     * @param d - the DrawSurface of the GUI we'll create later.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(new Color(91, 126, 211));
        d.fillRectangle(0, 0, 800, 600);


        d.setColor(Color.WHITE);
        for (int i = 0; i < 10; i++) {
            d.drawLine(145 + (i * 10), 350, 120 + (i * 10), 600);
        }

        d.setColor(new Color(188, 186, 164));
        d.fillCircle(140, 360, 20);
        d.fillCircle(165, 380, 30);
        d.setColor(new Color(172, 170, 142));
        d.fillCircle(180, 350, 30);
        d.fillCircle(220, 360, 30);
        d.fillCircle(200, 385, 25);


        d.setColor(Color.WHITE);
        for (int i = 0; i < 10; i++) {
            d.drawLine(545 + (i * 10), 430, 510 + (i * 10), 600);
        }

        d.setColor(new Color(188, 186, 164));
        d.fillCircle(540, 440, 20);
        d.fillCircle(565, 460, 30);
        d.setColor(new Color(172, 170, 142));
        d.fillCircle(580, 430, 30);
        d.fillCircle(620, 440, 30);
        d.fillCircle(600, 465, 25);

    }

    /**
     * notify the sprite that time has passed.
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {

    }
}
