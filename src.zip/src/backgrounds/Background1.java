package backgrounds;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;

/**
 * This Class describes the Background of levelsandgame.Level1 Class by implementing interfaces.Sprite.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class Background1 implements Sprite {

    /**
     * the function draws the sprite on the screen (using DrawSurface d).
     *
     * @param d - the DrawSurface of the GUI we'll create later.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(Color.BLACK);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(new Color(14, 30, 180));
        d.drawCircle(400, 170, 120);
        d.drawCircle(400, 170, 90);
        d.drawCircle(400, 170, 60);
        d.drawLine(400, 190, 400, 340);
        d.drawLine(400, 0, 400, 150);
        d.drawLine(210, 170, 360, 170);
        d.drawLine(440, 170, 590, 170);


    }

    /**
     * notify the sprite that time has passed.
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {

    }
}
