package backgrounds;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;
import java.awt.Image;

/**
 * this Object draws the level background with either a Color or an Image.
 * it can get an Image or a color, but once we use this object we'll always initiallize it with only one of them.
 */
public class LevelBackground implements Sprite {
    private Color color;
    private Image image;

    /**
     * constructor.
     *
     * @param color color
     * @param image image
     */
    public LevelBackground(Color color, Image image) {
        this.color = color;
        this.image = image;
    }

    /**
     * the function draws the sprite on the screen (using DrawSurface d).
     *
     * @param d - the DrawSurface of the GUI we'll create later.
     */
    public void drawOn(DrawSurface d) {
        if (this.image != null) {
            d.drawImage(0, 0, this.image);
        } else {
            d.setColor(color);
            d.fillRectangle(0, 0, d.getWidth(), d.getHeight());
        }

    }

    /**
     * notify the sprite that time has passed.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {

    }
}
