package highscorestablep;
/*
 * Idan Twito
 * 311125249
 */

import animations.AnimationRunner;
import animations.MenuAnimation;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import interfaces.LevelInformation;
import interfaces.Menu;
import interfaces.Task;
import readingfromfiles.LevelSpecificationReader;
import tasks.CloseGameTask;
import tasks.ShowGameTask;
import tasks.ShowHiScoresTask;

import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.InputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * This Class creates a game object, initializes and runs it.
 *
 * @ 20.04.18
 * @ Last UpdateL 21.05.18
 * @ author: Idan Twito
 */

public class Ass6Game {

    /**
     * reads from each level set Text File.
     *
     * @param ar          animations.AnimationRunner
     * @param menu        main menu
     * @param levelPath   the File path
     * @param ks          this keyboard
     * @param scoresTable the High Scores Table of this Game
     */
    public static void levelSetRead(AnimationRunner ar, Menu<Task<Void>> menu,
                                    String levelPath, KeyboardSensor ks, HighScoresTable scoresTable) {

        try {
            String lineStr;
            InputStreamReader is =
                    new InputStreamReader(ClassLoader.getSystemClassLoader().getResourceAsStream(levelPath));

            LineNumberReader lineReader = new LineNumberReader(is);
            lineStr = lineReader.readLine();
            List<LevelInformation> levels;
            String[] arrayByColon;
            String leftSideStr;
            String rightSideStr = null;
            String stopButton = null;
            while (lineStr != null) {
                if (lineReader.getLineNumber() % 2 == 0) {
                    try {
                        InputStream inputStream = ClassLoader.getSystemClassLoader().getResourceAsStream(lineStr);
                        InputStreamReader streamReader = new InputStreamReader(inputStream);
                        LevelSpecificationReader levelSpReader = new LevelSpecificationReader();
                        levels = levelSpReader.fromReader(streamReader);
                        ShowGameTask gameTask = new ShowGameTask(new GameFlow(ar, ks, scoresTable), levels);
                        menu.addSelection(stopButton, rightSideStr, gameTask);
                    } catch (Exception e) {
                        System.out.println("something went wrong while reading from set level Text File");
                    }
                } else {
                    arrayByColon = lineStr.split(":");
                    leftSideStr = arrayByColon[0].trim();
                    stopButton = leftSideStr.substring(0, 1);
                    rightSideStr = arrayByColon[1].trim();

                }

                lineStr = lineReader.readLine();
            }
        } catch (Exception e) {
            System.out.println("couldn't read the Level Set Text File");
        }

    }

    /**
     * the main method of highscorestablep.Ass6Game. it implements what written above.
     *
     * @param args gets no parameters.
     */
    public static void main(String[] args) {
        String txtFile;
        if (args.length >= 1) {
            txtFile = args[0];
        } else {
            txtFile = "level_sets.txt";
        }
        GUI gui = new GUI("Arkanoid", 800, 600);
        AnimationRunner ar = new AnimationRunner(gui, 60);
        List<LevelInformation> levels = new ArrayList<>();
        LevelSpecificationReader levelReader = new LevelSpecificationReader();
        KeyboardSensor ks = gui.getKeyboardSensor();
    /*    try {
            InputStreamReader reader = new InputStreamReader(ClassLoader.getSystemClassLoader().
                    getResourceAsStream("definitions/level_definitions.txt"));
            levelsandgame = levelReader.fromReader(reader);
        } catch (Exception e) {
            System.out.println("an Error occurred while reading level definition txt");
        }*/
        //tries to load the existing highscores.txt Table, if it doesn't exist - create new one.
        HighScoresTable scoresTable = new HighScoresTable(5);
        try {
            scoresTable.load(new File("highscores.txt"));
        } catch (Exception e) {
            System.out.println("Something went wrong while loading from highscores.txt.");
        }
        while (true) {
            Menu<Task<Void>> levelSetsMenu = new MenuAnimation<>(ar, "Game-Level", ks);
            levelSetRead(ar, levelSetsMenu, txtFile, ks, scoresTable);
            Menu<Task<Void>> menu = new MenuAnimation<Task<Void>>(ar, "Arkanoid-Game", ks);
            menu.addSubMenu("s", "Start Game", levelSetsMenu);
            menu.addSelection("h", "High Scores Table", new ShowHiScoresTask(ar,
                    new HighScoresAnimation(scoresTable), ks));
            // menu.addSelection("s", "Start Game", new tasks.ShowGameTask(new highscorestablep.
            // GameFlow(ar, ks, scoresTable), levelsandgame));
            menu.addSelection("q", "Close Game", new CloseGameTask());
            //runs menu interfaces.Animation
            ar.run(menu);
            // wait for user selection and gets the status from the menu. once one of the keys in keyList(see in
            //menu Object for more info), task gets the corresponding task,
            // which runs the corresponding interfaces.Animation.
            Task<Void> task = menu.getStatus();
            task.run();
            //tells the menu interfaces.Animation that its interfaces.Animation is not over.
            ((MenuAnimation<Task<Void>>) menu).stopAnimation();
        }
    }
}