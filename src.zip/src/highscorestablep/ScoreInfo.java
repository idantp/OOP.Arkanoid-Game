package highscorestablep;
/*
 * Idan Twito
 * 311125249
 */

import java.io.Serializable;

/**
 * Describes each member in HighScoreTable. contains the name and the player's score
 */
public class ScoreInfo implements Serializable {
    private String name;
    private int score;

    /**
     * constructor.
     *
     * @param name  - player's name.
     * @param score - player's score.
     */
    public ScoreInfo(String name, int score) {
        this.name = name;
        this.score = score;
    }

    /**
     * return player's name.
     *
     * @return this.name String
     */
    public String getName() {
        return this.name;
    }

    /**
     * return player's score.
     *
     * @return - this.score int
     */
    public int getScore() {
        return this.score;
    }
}