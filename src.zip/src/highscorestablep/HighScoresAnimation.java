package highscorestablep;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Animation;

import java.awt.Color;

/**
 * creates a graphical representation of the scores,
 * It will display the scores in the high-scores table, until a SPACE KEY is pressed.
 */
public class HighScoresAnimation implements Animation {
    private HighScoresTable scores;
    private boolean stop;

    /**
     * constructor.
     *
     * @param scores HighScoresTable object
     */
    public HighScoresAnimation(HighScoresTable scores) {
        this.scores = scores;
        this.stop = false;

    }

    /**
     * in charge of the logic of each animation.
     *
     * @param d  this drawsurface is given from the animations.AnimationRunner
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void doOneFrame(DrawSurface d, double dt) {


        //the start height of the table
        int height = d.getHeight() / 5;
        //indicates where we write the names
        int nameWidth = d.getWidth() / 6;
        //indicates where we write the scores
        int scoreWidth = d.getWidth() - 250;
        //the space between each line in the table
        int space = 45;
        //the background.
        d.setColor(new Color(0xBCBC95));
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(new Color(0xE6DA27));
        d.fillRectangle((d.getWidth() / 3) + 18, d.getHeight() / 10 + 10, 215, 5);
        d.drawText((d.getWidth() / 3) + 20, d.getHeight() / 10, "High Scores", 40);
        d.setColor(new Color(0x4E4A0D));
        d.drawText(d.getWidth() / 5, d.getHeight() - 120, "Press SPACE to go Back", 40);
        d.setColor(Color.BLACK);
        d.drawText(nameWidth, height, "Player's Name", 30);
        d.drawText(scoreWidth, height, "Score", 30);
        d.fillRectangle(nameWidth, height + 5, 195, 3);
        d.fillRectangle(scoreWidth, height + 5, 80, 3);
        height += space;
        //drawing the all scores and the corresponding player's name in different lines.
        for (int i = 0; i < this.scores.size(); i++) {
            d.drawText(scoreWidth, height, Integer.toString(scores.getHighScores().get(i).getScore()), 30);
            d.drawText(nameWidth, height, (scores.getHighScores().get(i).getName()), 30);
            d.fillRectangle(nameWidth, height + 5, 500, 3);
            height += space;
        }
    }

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
