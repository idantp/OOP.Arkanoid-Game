package highscorestablep;
/*
 * Idan Twito
 * 311125249
 */

import java.io.File;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;


/**
 * Table that stores the historic high scores which will manage a table of size high-scores.
 */
class HighScoresTable implements Serializable {
    //List the contains the scores and the player's name.
    private List<ScoreInfo> scoreInfoCollection;
    //max scores the can be shown
    private int maxSize;

    /**
     * Create an empty high-scores table with the specified maxSize.
     * The maxSize means that the table holds up to maxSize top scores.
     *
     * @param size indicates the max scores in the table.
     */
    public HighScoresTable(int size) {
        scoreInfoCollection = new ArrayList<ScoreInfo>();
        this.maxSize = size;
    }

    /**
     * Add a high-score.
     *
     * @param score the score we want to add.
     */
    public void add(ScoreInfo score) {
        //gets the the rank where the score should be placed
        int rank = getRank(score.getScore());
        if (rank > 0) {
            scoreInfoCollection.add(rank - 1, score);
        }
    }

    /**
     * Return the current amount of scores in this table.
     *
     * @return this.scoreInfoCollection.size().
     */
    public int size() {
        if (this.scoreInfoCollection.size() < maxSize) {
            return this.scoreInfoCollection.size();
        } else {
            return maxSize;
        }
    }

    /**
     * Return the current high scores.
     * The list is sorted such that the highest
     * scores come first.
     *
     * @return this.scoreInfoCollection
     */
    public List<ScoreInfo> getHighScores() {
        return this.scoreInfoCollection;
    }


    /**
     * return the rank of the current score: where will it
     * be on the list if added?
     * Rank 1 means the score will be highest on the list.
     * Rank `maxSize` means the score will be lowest.
     * Rank > `maxSize` means the score is too low and will not
     * be added to the list - return -1.
     *
     * @param score the score we want to check whether we need to add or not.
     * @return int index which tell us whether to add it or not
     */
    public int getRank(int score) {
        for (int i = 0; i < size(); i++) {
            if (score > this.scoreInfoCollection.get(i).getScore()) {
                return i + 1;
            }
        }
        if (size() < maxSize) {
            return (size() + 1);
        }
        return -1;
    }

    /**
     * Clears the table.
     */
    public void clear() {
        this.scoreInfoCollection.clear();
    }

    /**
     * Load table data from file.
     *
     * @param filename the file's path which contains the Table
     * @throws IOException might throw IOException
     */
    public void load(File filename) throws IOException {
        //loads the table from filename
        HighScoresTable scoresTable = HighScoresTable.loadFromFile(filename);
        //if the Table is not empty, upddate the values it contains.
        if (scoresTable != null) {
            this.scoreInfoCollection = scoresTable.scoreInfoCollection;
            this.maxSize = scoresTable.maxSize;
        }
    }

    /**
     * Save table data to the specified file.
     *
     * @param filename the file's path which contains the Table
     * @throws IOException might throw IOException
     */
    public void save(File filename) throws IOException {
        FileOutputStream fileOutputStream;
        ObjectOutputStream objectOutputStream = null;
        //we want to save the details to filename, in order to do this well have to open filename for writing
        //wed like to write to it HighScoreTAble later.
        try {
            fileOutputStream = new FileOutputStream(filename);
            //create an object knows to save an object.
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            //write "this"
            objectOutputStream.writeObject(this);
            //if something went wrong while writing
        } catch (Exception e) {
            System.out.println("Something went wrong while writing.");
        } finally {
            if (objectOutputStream != null) {
                try {
                    objectOutputStream.close();
                } catch (IOException e) {
                    System.out.println("Failed closing the file!");
                }
            }
        }
    }

    /**
     * Read a table from file and return it.If the file does not exist, or there is a problem with
     * reading it, an empty table is returned.
     *
     * @param filename the file's path
     * @return null or highscorestablep.HighScoresTable.
     */
    public static HighScoresTable loadFromFile(File filename) {
        FileInputStream fileInputStream = null;
        //tries to load a highscorestablep.HighScoresTable from filename.
        try {
            fileInputStream = new FileInputStream(filename);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            return (HighScoresTable) objectInputStream.readObject();
            //if couldnt load it - create a new file and return a new Table.
        } catch (Exception e) {
            try {
                //creates new File "highscores.txt" once we dont have one
                filename.createNewFile();
            } catch (IOException exc) {
                System.out.println("couldn't create new highscores.txt File ");
            }
            HighScoresTable highScoresTable = new HighScoresTable(5);
            try {
                //saves the new Table to the new filename
                highScoresTable.save(filename);
            } catch (IOException e1) {
                System.out.println("Couldnt save new table to highscores.txt");
            }
            return highScoresTable;
            //closes fileInputStream
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
            } catch (IOException e) {
                System.out.println("Failed closing highscores.txt File");
            }
        }
    }
}

