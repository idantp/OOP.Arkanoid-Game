package readingfromfiles;
/*
 * Idan Twito
 * 311125249
 */

import blockandpaddle.Block;
import geometricshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.util.List;

/**
 * This Object describes a Level in the way of reading Levels information from Text Files.
 */
public class LevelInfoByParse implements LevelInformation {
    //members
    private List<Velocity> velocities;
    private int paddleSpeedVar;
    private int paddleWidthVar;
    private String levelNameStr;
    private Sprite levelBackground;
    private List<Block> blocksPattern;
    private int blockToRemove;

    /**
     * Constructor.
     *
     * @param velocities      velocities of the balls
     * @param paddleSpeedVar  this level paddle speed
     * @param paddleWidthVar  the paddle width
     * @param levelNameStr    the Level's name
     * @param levelBackground the level's Background
     * @param blocksPattern   the level blockandpaddle.Block pattern (described in a list)
     * @param blockToRemove   how much blocks were left to remove for passing this level
     */
    public LevelInfoByParse(List<Velocity> velocities, int paddleSpeedVar, int paddleWidthVar
            , String levelNameStr, Sprite levelBackground, List<Block> blocksPattern, int blockToRemove) {
        this.velocities = velocities;
        this.paddleSpeedVar = paddleSpeedVar;
        this.paddleWidthVar = paddleWidthVar;
        this.levelNameStr = levelNameStr;
        this.levelBackground = levelBackground;
        this.blockToRemove = blockToRemove;
        this.blocksPattern = blocksPattern;
    }

    /**
     * number of balls in this Level.
     *
     * @return number of balls in this level.
     */
    public int numberOfBalls() {
        return velocities.size();
    }

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return list that contains all the velocity of each ball correspondingly
     */
    public List<Velocity> initialBallVelocities() {
        return velocities;
    }

    /**
     * the blockandpaddle.Paddle's geometricshapes.Velocity.
     *
     * @return the paddle's velocity.
     */
    public int paddleSpeed() {
        return paddleSpeedVar;
    }

    /**
     * The blockandpaddle.Paddle's Width.
     *
     * @return the paddle's width.
     */
    public int paddleWidth() {
        return paddleWidthVar;
    }

    /**
     * the level name will be displayed at the top of the screen.
     *
     * @return string with the level's Name
     */
    public String levelName() {
        return levelNameStr;
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return interfaces.Sprite that describes the level's Background
     */
    public Sprite getBackground() {
        return levelBackground;
    }

    /**
     * The Blocks that make up this level, each block contains.
     * its size, color and location.
     *
     * @return list of Blocks that contains all the Blocks in this Level
     */
    public List<Block> blocks() {
        return blocksPattern;
    }

    /**
     * Number of levelsandgame that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size().
     *
     * @return int Number of levelsandgame that should be removed before we skip to the next level.
     */
    public int numberOfBlocksToRemove() {
        return blockToRemove;
    }
}
