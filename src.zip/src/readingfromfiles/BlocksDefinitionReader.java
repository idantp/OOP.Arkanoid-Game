package readingfromfiles;
/*
 * Idan Twito
 * 311125249
 */

import blockandpaddle.Block;
import blockandpaddle.BlocksFromSymbolsFactory;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import interfaces.BlockCreator;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * This Class gets a java.io.Reader Object to a file which describes blocks. it extracts separately the
 * default, sdef,bdef lines (from blocks_*.txt) into 3 different Array lists. then we integrate them into
 * ArrayList <ArrayList<String>> and returns it.
 * then, it can map those lists into 2 different tree maps.
 */
public class BlocksDefinitionReader {
    /**
     * extracts separately the sdef,bdef lines (from blocks_*.txt) into Array lists and returns the Array List.
     *
     * @param reader java.io.Reader Object to a file
     * @return ArrayList blocksLevelDescription
     */
    public static ArrayList<ArrayList<String>> blocksLevelDescription(java.io.Reader reader) {
        BufferedReader is = null;
        String[] arraySplitter;
        //an ArrayList that gets Strings from default line, contains in each member "str:str"
        ArrayList<String> defaultSeparatedBySpacesList = new ArrayList<>();
        //contains in each member a line that starts with "bdef"
        ArrayList<String> bdefLinesList = new ArrayList<>();
        //contains in each member a line that starts with "cdef"
        ArrayList<String> sdefLinesList = new ArrayList<>();
        //contains all the 3 ArrayLists above
        ArrayList<ArrayList<String>> defaultBdefSdefList = new ArrayList<>();
        String line;

        //creating an array list of default lines
        try {
            //wrapper that reads ahead, then wrapper that reads chars.
            is = new BufferedReader(reader);
            line = is.readLine().trim();
            while (line != null) {
                //creating an array list which contains in each member "str:str"
                if (line.trim().startsWith("default")) {
                    arraySplitter = line.split(" ");
                    for (String string : arraySplitter) {
                        //remove "default" from the list
                        if (string.contains("default")) {
                            continue;
                        } else {
                            defaultSeparatedBySpacesList.add(string.trim());
                        }
                    }
                } else if (line.trim().startsWith("bdef")) {
                    //creating an array list which contains in each member line of String starts with "bdef"
                    bdefLinesList.add(line);
                } else if (line.trim().startsWith("sdef")) {
                    //creating an array list which contains in each member line of String starts with "bdef"
                    sdefLinesList.add(line);
                }
                line = is.readLine().trim();
            }
        } catch (IOException e) {
            System.out.println(" Something went wrong while reading ! 64");
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    System.out.println("Failed closing the File");
                }
            }
            //integrates all the 3 array lists into ArrayList<ArrayList<String>>.
            defaultBdefSdefList.add(defaultSeparatedBySpacesList);
            defaultBdefSdefList.add(bdefLinesList);
            defaultBdefSdefList.add(sdefLinesList);
            return defaultBdefSdefList;
        }
    }

    /**
     * gets a list contains the default line and each member is separated from the other with SPACE.
     * every member looks like: "string:string". we'll return a map that its keys get the left strings in the colon
     * of every member in the array, the values in the map gets the right strings in the colon.
     *
     * @param defaultSeparatedBySpacesList the list we get
     * @return Map mappingDefaultLine
     */
    public static Map<String, String> mappingDefaultLine(ArrayList<String> defaultSeparatedBySpacesList) {
        Map<String, String> defaultLineMap = new TreeMap<>();
        String[] stringArray;
        //if the given list is empty return null;
        if (defaultSeparatedBySpacesList.size() == 0) {
            return null;
        } else {
            //runs on every member, the keys in the map gets the left strings in the colon of every member in
            //the array, the values in the map gets the right strings in the colon.
            for (String str : defaultSeparatedBySpacesList) {
                if (str.contains(":")) {
                    stringArray = str.split(":");
                    String key = stringArray[0].trim();
                    String value = stringArray[1].trim();
                    defaultLineMap.put(key, value);
                }
            }
        }
        return defaultLineMap;
    }

    /**
     * gets a list that contains the sdef or bdef lines(Strings) as members. we will create a map that the key
     * will hold the symbol of each bdef/sdef, the values will be Map<String, String> that its keys get the left
     * strings in the colon of every member in the array, the values in the map gets the right strings in the colon.
     *
     * @param defLinesList List<String>
     * @return Map mappingDefLines Map<String, Map<String, String>>
     */
    public static Map<String, Map<String, String>> mappingDefLines(List<String> defLinesList) {
        //maps all the pairs(str:str) in each line except for the symbol pair(symbol:char).
        Map<String, String> mapPairsNoSymbol = new TreeMap<>();
        //the map well return
        Map<String, Map<String, String>> mapBySymbols = new TreeMap<String, Map<String, String>>();
        String[] splitBySpaceArray;
        String symbolStr = null;
        //splitting by spaces the array
        for (String line : defLinesList) {
            splitBySpaceArray = line.split(" ");
            //splitting the members by ":"
            for (int i = 1; i < splitBySpaceArray.length; i++) {
                String[] splitByColonArray = splitBySpaceArray[i].split(":");
                if (splitByColonArray[0].trim().equals("symbol")) {
                    symbolStr = splitByColonArray[1].trim();
                } else {
                    mapPairsNoSymbol.put(splitByColonArray[0].trim(), splitByColonArray[1].trim());
                }
            }
            //if symbol missing return null
            if (symbolStr == null) {
                return null;
            }
            //the return map.
            mapBySymbols.put(symbolStr, mapPairsNoSymbol);
            mapPairsNoSymbol = new TreeMap<>();
        }
        return mapBySymbols;
    }

    /**
     * gets a map describes the bdef Lines in level definition Text, and returns
     * a Map within BlockCreators values.
     *
     * @param mappingBdefLines the map looks like: "block's symbol -> (bdef definition -> definition's values)
     * @return blockCreatorMap a Map within BlockCreators values.
     */
    public static Map<String, BlockCreator> creatorMap(Map<String, Map<String, String>> mappingBdefLines) {
        String firstKeys = null;
        Map<String, String> values = new TreeMap<>();
        Map<String, BlockCreator> blockCreatorMap = new TreeMap<>();
        String imageStr;
        for (Map.Entry<String, Map<String, String>> m : mappingBdefLines.entrySet()) {
            Map<Integer, Color> integerColorMap = new TreeMap<>();
            Map<Integer, Image> integerImageMap = new TreeMap<>();
            firstKeys = m.getKey();
            values = m.getValue();
            int height = Integer.parseInt(values.get("height"));
            int width = Integer.parseInt(values.get("width"));
            int hitPoints = Integer.parseInt(values.get("hit_points"));
            String strokeStr;
            if (values.containsKey("stroke")) {
                strokeStr = values.get("stroke");
            } else {

                strokeStr = null;
            }
            Color stroke = null;
            if (strokeStr != null) {
                try {
                    stroke = ColorParser.colorFromString(strokeStr);

                } catch (Exception e) {
                    e.getMessage();
                }
            }
            final Color finalStroke = stroke;
            ColorParser colorsParser = new ColorParser();
            for (String keys : values.keySet()) {
                if (keys.trim().equals("fill")) {
                    if (values.get(keys).trim().startsWith("image")) {
                        imageStr = values.get(keys).replace("image(", "").replace(")",
                                "");
                        try {
                            integerImageMap.put(1, ImageIO.read(ClassLoader.getSystemClassLoader().
                                    getResourceAsStream(imageStr)));
                        } catch (IOException e) {
                            System.out.println("Couldn't load the Image");
                            System.exit(1);
                        }
                    } else {
                        try {
                            integerColorMap.put(1, colorsParser.colorFromString(values.get(keys)));
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.exit(1);
                        }
                    }
                } else if (keys.startsWith("fill-")) {
                    int k = Integer.parseInt(keys.replace("fill-", "").trim());
                    if (values.get(keys).trim().startsWith("image")) {
                        imageStr = values.get(keys).replace("image(", "").replace(")", "");
                        try {
                            integerImageMap.put(k, ImageIO.read(ClassLoader.getSystemClassLoader().
                                    getResourceAsStream(imageStr)));
                        } catch (IOException e) {
                            System.out.println("Couldn't load the Image");
                            System.exit(1);
                        }
                    } else {
                        try {
                            integerColorMap.put(k, colorsParser.colorFromString(values.get(keys)));
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.exit(1);
                        }
                    }
                }
            }
            //Create anonymous Class
            BlockCreator blockCreator = new BlockCreator() {
                @Override
                public Block create(int xpos, int ypos) {
                    Rectangle rect = new Rectangle(new Point(xpos, ypos), width, height);
                    Block blockGame = new Block(rect, integerImageMap, integerColorMap, hitPoints);

                    blockGame.addStrokeToBlock(finalStroke);
                    return blockGame;
                }
            };
            blockCreatorMap.put(firstKeys, blockCreator);
        }
        return blockCreatorMap;
    }

    /**
     * gets a map describes the sdef Lines in level definition Text, and returns
     * a Map within the widths of the Spacers (in the Map's values).
     *
     * @param mappingSdefLines the map looks like: "spacer's symbol -> (sdef definition -> definition's values)
     * @return sdefStrInteger a Map within the widths of the Spacers (in the Map's values).
     */

    public static Map<String, Integer> spacesMap(Map<String, Map<String, String>> mappingSdefLines) {
        Map<String, Integer> sdefStrInteger = new TreeMap<>();
        for (Map.Entry<String, Map<String, String>> entry : mappingSdefLines.entrySet()) {
            sdefStrInteger.put(entry.getKey(), Integer.parseInt(entry.getValue().get("width")));
        }
        return sdefStrInteger;
    }

    /**
     * the method gets 2 maps: the first is the bdef Map, the second is the default Map.
     * it checks whether the default line contain a key/property, which a certain blockandpaddle.
     * Block doesn't and adds it
     * to the same blockandpaddle.Block map.
     *
     * @param defLinesMap    the bdef Map
     * @param defaultLineMap the default line Map
     */
    public static void missingKeyTryDefault(Map<String, Map<String, String>> defLinesMap,
                                            Map<String, String> defaultLineMap) {
        //all the fields a blockandpaddle.Block must contain
        String[] defaultFields = {"width", "height", "hit_points", "stroke"};
        //runs all the entries of defLinesMap.
        if (defaultLineMap != null) {
            for (Map.Entry<String, Map<String, String>> defMapEntry : defLinesMap.entrySet()) {
                //checking if there is a field in defaultFields missing in bdef and default line
                for (String defaultKeyStr : defaultFields) {
                    //if "fill" and "fill-1" are missing in a bdef line and the default line: print message
                    if ((!(defMapEntry.getValue().containsKey("fill")) && !(defaultLineMap.containsKey("fill")))
                            && (!(defMapEntry.getValue().containsKey("fill-1"))
                            && !(defaultLineMap.containsKey("fill-1")))) {
                        System.out.println("The following fields: \"fill or fill-1\""
                                + " are missing in both: bdef and default lines");
                        System.exit(0);
                    } else if (!(defMapEntry.getValue().containsKey("fill"))
                            && !(defMapEntry.getValue().containsKey("fill-1"))) {
                        //if the field "fill" is missing in a bdef but exists in the default line, add it to bdef line
                        if (defaultLineMap.containsKey("fill")) {
                            defMapEntry.getValue().put("fill", defaultLineMap.get("fill"));
                        } else if (defaultLineMap.containsKey("fill-1")) {
                            //if the field "fill-1" is missing in a bdef but exists in the default line,
                            // add it to bdef line
                            defMapEntry.getValue().put("fill-1", defaultLineMap.get("fill-1"));
                        }
                    }
                    //if there's a field missing in both: bdef and default line
                    if (!(defMapEntry.getValue().containsKey(defaultKeyStr))
                            && !(defaultLineMap.containsKey(defaultKeyStr)) && !defaultKeyStr.equals("stroke")) {
                        System.out.println("The following field: \"" + defaultKeyStr
                                + "\" is missing in both: bdef and default lines");
                        //if the given field is missing in bdef line but exists in a default line,
                        // add it to the bdef line
                    } else if (!(defMapEntry.getValue().containsKey(defaultKeyStr))
                            && (defaultLineMap.containsKey(defaultKeyStr))) {
                        defMapEntry.getValue().put(defaultKeyStr, defaultLineMap.get(defaultKeyStr));
                    }
                }
            }
        }
    }

    /**
     * The method reads the bdef,sdef and default text Lines. it creates the appropriate Blocks and Spacers
     * according to those lines regarding to the default line (if there's a missing value of the bdef or lines,
     * we try to draw this value from the default line).
     *
     * @param reader Text File reader.
     * @return blockandpaddle.BlocksFromSymbolsFactory
     */
    public static BlocksFromSymbolsFactory fromReader(java.io.Reader reader) {
        List<ArrayList<String>> blocksLeveldesc = blocksLevelDescription(reader);
        if (blocksLeveldesc == null) {
            System.out.println("no lines were found in the text");
            System.exit(0);
        }
        Map<String, String> defaultLineMap = mappingDefaultLine(blocksLeveldesc.get(0));
        Map<String, Map<String, String>> bdefMap = mappingDefLines(blocksLeveldesc.get(1));
        Map<String, Map<String, String>> sdefMap = mappingDefLines(blocksLeveldesc.get(2));
        missingKeyTryDefault(bdefMap, defaultLineMap);
        Map<String, BlockCreator> blockCreatorMap = creatorMap(bdefMap);
        Map<String, Integer> stringIntegerMap = spacesMap(sdefMap);
        BlocksFromSymbolsFactory blocksFromSymbolsFactory =
                new BlocksFromSymbolsFactory(stringIntegerMap, blockCreatorMap);
        return blocksFromSymbolsFactory;

    }
}
