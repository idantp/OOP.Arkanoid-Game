package indicators;
/*
 * Idan Twito
 * 311125249
 */

import blockandpaddle.Block;
import geometricshapes.Ball;
import interfaces.HitListener;

/**
 * This class keeps the player's score. Points are gained by the following rules:
 * hitting a block is worth 5 points, and destroying a block is worth and additional 10 points.
 * Clearing an entire level (destroying all blocks) is worth
 * another 100 points - this rule is implemented in blockandpaddle.BlockRemover.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class ScoreTrackingListener implements HitListener {
    //member
    private Counter currentScore;

    /**
     * Constructor.
     *
     * @param scoreCounter - contains the score of the player
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    /**
     * Updates the score by the rules that were described in the Class Doc'.
     *
     * @param beingHit the blockandpaddle.Block that was involved in the hit
     * @param hitter   the geometricshapes.Ball that was involved in the hit
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        currentScore.increase(5);
        if (beingHit.getHitPoints() == 0) {
            currentScore.increase(10);
        }
    }
}
