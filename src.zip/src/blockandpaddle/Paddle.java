package blockandpaddle;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import geometricshapes.Velocity;
import geometricshapes.Line;
import geometricshapes.Ball;
import interfaces.Collidable;
import interfaces.Sprite;
import levelsandgame.GameLevel;

import java.awt.Color;

/**
 * blockandpaddle.Paddle describes the player in the Game. it's a geometricshapes.Rectangle which implements interfaces.
 * Sprite and interfaces.Collidable.
 * it can move right al left according to the key presses.
 *
 * @ 20.04.18
 * @ last update: 21.05.18
 * @ author: Idan Twito
 */
public class Paddle implements Sprite, Collidable {
    private KeyboardSensor keyboard;
    private Color color;
    private Rectangle rectangle;
    private double velocity;
    private double leftBorder;
    private double rightBorder;

    /**
     * the constructor of the blockandpaddle.Paddle.
     *
     * @param keyboard    - reading the keys from the given keyboard
     * @param color       - the Color of the blockandpaddle.Paddle.
     * @param rectangle   - the geometricshapes.Rectangle that describes the blockandpaddle.Paddle.
     * @param velocity    - the velocity that describes the blockandpaddle.Paddle.
     * @param leftBorder  - the X coordinate which the paddle cant pass from the left.
     * @param rightBorder - the X coordinate which the paddle cant pass from the right.
     */
    public Paddle(KeyboardSensor keyboard, Color color, Rectangle rectangle, double velocity,
                  double leftBorder, double rightBorder) {
        Point upperLeft = new Point(rectangle.getUpperLeft().getX(), rectangle.getUpperLeft().getY());
        this.keyboard = keyboard;
        this.color = color;
        this.velocity = velocity;
        this.leftBorder = leftBorder;
        this.rightBorder = rightBorder;
        this.rectangle = new Rectangle(upperLeft, rectangle.getWidth(), rectangle.getHeight());
    }

    /**
     * moving the paddle to the left.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void moveLeft(double dt) {
        Point newUpperLeft;
        //makes sure the speed depends on frames per seconds
        double tempVelocity = velocity * dt;
        //and the blockandpaddle.Paddle might cross the left Border - make sure the paddle doesnt pass this border.
        if (this.rectangle.getUpperLeft().getX() - tempVelocity < (this.leftBorder + 5)) {
            newUpperLeft = new Point(this.leftBorder + 5, this.rectangle.getUpperLeft().getY());
            this.rectangle.setUpperLeft(newUpperLeft);
        } else {
            newUpperLeft = new Point(this.rectangle.getUpperLeft().getX() - tempVelocity,
                    this.rectangle.getUpperLeft().getY());
            //otherwise: moving the blockandpaddle.Paddle according to its geometricshapes.Velocity.
            this.rectangle.setUpperLeft(newUpperLeft);
        }
    }


    /**
     * moving the paddle to the right.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void moveRight(double dt) {
        Point newUpperLeft;
        double tempVelocity = velocity * dt;
        //and the blockandpaddle.Paddle might cross the right Border - make sure the paddle doesnt pass this border.
        if (this.rectangle.getUpperRight().getX() + tempVelocity > (this.rightBorder - 5)) {
            newUpperLeft = new Point((this.rightBorder - 5) - this.rectangle.getWidth(),
                    this.rectangle.getUpperLeft().getY());
            this.rectangle.setUpperLeft(newUpperLeft);
        } else {
            newUpperLeft = new Point(this.rectangle.getUpperLeft().getX() + tempVelocity,
                    this.rectangle.getUpperLeft().getY());
            //otherwise: moving the blockandpaddle.Paddle according to its geometricshapes.Velocity.
            this.rectangle.setUpperLeft(newUpperLeft);
        }
    }

    /**
     * if time passed - see if moving is required.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {
        //if the right arrow in the keyboard is pressed
        if (keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            this.moveRight(dt);
        }
        //if the left arrow in the keyboard is pressed
        if (keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            this.moveLeft(dt);
        }
    }

    /**
     * drawing the paddle and its lines.
     *
     * @param d - the DrawSurface of the GUI of the Game create.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
        d.setColor(Color.BLACK);
        d.drawRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());

    }

    /**
     * returning the rectangle when there was a collision.
     *
     * @return - geometricshapes.Rectangle this.rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.rectangle;
    }

    /**
     * given there was a collision of an object with this blockandpaddle.Paddle, the function returns the new velocity
     * of the colliding object after the hit with this blockandpaddle.Paddle.
     *
     * @param collisionPoint  geometricshapes.Point that describes the collision point.
     * @param currentVelocity geometricshapes.Velocity - the current velocity of the colliding object.
     * @param hitter          - the geometricshapes.Ball that is involved in the this hit.
     * @return geometricshapes.Velocity newVelocity - the new velocity of the geometricshapes.Ball.
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        //declaring the sides of the rectangle
        Line upperL = this.rectangle.getUpperLine();
        Line lowerL = this.rectangle.getLowerLine();
        //the fifth size of the blockandpaddle.Paddle width
        double fifthPaddle = (this.rectangle.getWidth() / 5);
        //the speed of the geometricshapes.Ball
        double speed = Math.sqrt(Math.pow(currentVelocity.getDx(), 2)
                + Math.pow(currentVelocity.getDy(), 2));
        //the new velocity we'll return
        Velocity newVelocity = currentVelocity;

        //if the geometricshapes.Ball collided with the paddle in its first fifth from the left
        if (collisionPoint.getX() <= (fifthPaddle + this.rectangle.getUpperLeft().getX())) {
            newVelocity = Velocity.fromAngleAndSpeed(300, speed);
            //if the geometricshapes.Ball collided with the paddle in its second fifth from the left
        } else if (collisionPoint.getX() > (fifthPaddle + this.rectangle.getUpperLeft().getX())
                && collisionPoint.getX() <= (2 * fifthPaddle + this.rectangle.getUpperLeft().getX())) {
            newVelocity = Velocity.fromAngleAndSpeed(330, speed);
            //if the geometricshapes.Ball collided with the paddle in its third fifth from the left
        } else if (collisionPoint.getX() > (2 * fifthPaddle + this.rectangle.getUpperLeft().getX())
                && collisionPoint.getX() <= (3 * fifthPaddle + this.rectangle.getUpperLeft().getX())) {
            //if there was a hit in the upper or lower side - the new velocity gets the vertical previous velocity
            if (currentVelocity.getDx() == 0) {
                newVelocity = Velocity.fromAngleAndSpeed(180, speed);
            }
            if (upperL.isPointIntersectLine(collisionPoint) || lowerL.isPointIntersectLine(collisionPoint)) {
                //set new velocity so the ball wont stuck inside the paddle
                newVelocity = new Velocity(currentVelocity.getDx(), (currentVelocity.getDy() * (-1)));
            } //if the geometricshapes.Ball collided with the paddle in its fourth fifth from the left
        } else if (collisionPoint.getX() > (3 * fifthPaddle + this.rectangle.getUpperLeft().getX())
                && collisionPoint.getX() <= (4 * fifthPaddle + this.rectangle.getUpperLeft().getX())) {
            newVelocity = Velocity.fromAngleAndSpeed(30, speed);
            //if the geometricshapes.Ball collided with the paddle in its fifth fifth from the left
        } else if (collisionPoint.getX() > (4 * fifthPaddle + this.rectangle.getUpperLeft().getX())
                && collisionPoint.getX() <= (5 * fifthPaddle + this.rectangle.getUpperLeft().getX())) {
            newVelocity = Velocity.fromAngleAndSpeed(60, speed);
        }
        return newVelocity;

    }

    /**
     * Add this paddle to the game.
     *
     * @param g Game
     */
    public void addToGame(GameLevel g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

    /**
     * Remove this paddle to the game.
     *
     * @param g Game
     */
    public void removeFromGame(GameLevel g) {
        g.removeSprite(this);
        g.removeCollidable(this);
    }
}