package blockandpaddle;
/*
 * Idan Twito
 * 311125249
 */

import interfaces.BlockCreator;

import java.util.Map;

/**
 * Gets a symbol and checks whether its a blockandpaddle.Block or a Space. It creates a corresponding blockandpaddle.
 * Block/Space to the symbol(if the symbol exists).
 */
public class BlocksFromSymbolsFactory {
    private Map<String, Integer> spacerWidths;
    private Map<String, BlockCreator> blockCreators;

    /**
     * constructor.
     *
     * @param spacerWidths  Maps of the Spaces (sdef)
     * @param blockCreators Maps of the Blocks (bdef)
     */
    public BlocksFromSymbolsFactory(Map<String, Integer> spacerWidths, Map<String, BlockCreator> blockCreators) {
        this.spacerWidths = spacerWidths;
        this.blockCreators = blockCreators;
    }

    /**
     * returns true if 's' is a valid space symbol.
     *
     * @param s String
     * @return boolean
     */
    public boolean isSpaceSymbol(String s) {
        return this.spacerWidths.containsKey(s);
    }

    /**
     * returns true if 's' is a valid block symbol.
     *
     * @param s String
     * @return boolean
     */
    public boolean isBlockSymbol(String s) {
        return this.blockCreators.containsKey(s);
    }

    /**
     * Return a block according to the definitions associated.
     * with symbol s. The block will be located at position (xpos, ypos).
     *
     * @param s    represents the letter of the blockandpaddle.Block
     * @param xpos x Coordinate of the upper left geometricshapes.Point of the blockandpaddle.
     *             Block's geometricshapes.Rectangle.
     * @param ypos y Coordinate of the upper left geometricshapes.Point of the blockandpaddle.
     *             Block's geometricshapes.Rectangle.
     * @return blockandpaddle.Block.
     */
    public Block getBlock(String s, int xpos, int ypos) {
        return this.blockCreators.get(s).create(xpos, ypos);
    }

    /**
     * Returns the width in pixels associated with the given spacer-symbol.
     *
     * @param s represents the letter of the blockandpaddle.Block
     * @return returns the spacer Width Integer.
     */
    public int getSpaceWidth(String s) {
        return this.spacerWidths.get(s);
    }
}
